// const express = require('express');
// const Todo = require('../models/todo');

// routers/todoRouter.js
const express = require('express');
const router = express.Router();
const Todo = require('../models/todo.js');

// POST - Add a new todo
router.post('/', async (req, res) => {
  try {
    const { todo } = req.body; // 从请求体接收数据
    const newTodo = new Todo({ todo, done: false });
    await newTodo.save();
    res.status(201).json(newTodo);
  } catch (err) {
    res.status(500).json({ message: 'Error adding todo', error: err.message });
  }
});

module.exports = router;
