const Todo = require('../model/Todo');

// 获取所有 todos
exports.getTodos = async (req, res) => {
  try {
    const todos = await Todo.find();
    res.json(todos);
  } catch (err) {
    res.status(500).send(err.message);
  }
};

// 添加新的 todo
exports.addTodo = async (req, res) => {
  try {
    const { text } = req.body;
    const newTodo = new Todo({ text });
    await newTodo.save();
    res.status(201).json(newTodo);
  } catch (err) {
    res.status(400).send(err.message);
  }
};

// 切换 todo 的完成状态
exports.toggleTodo = async (req, res) => {
  try {
    const todo = await Todo.findById(req.params.id);
    if (!todo) {
      return res.status(404).send("Todo not found");
    }
    todo.completed = !todo.completed;
    await todo.save();
    res.json(todo);
  } catch (err) {
    res.status(400).send(err.message);
  }
};

// 删除一个 todo
exports.deleteTodo = async (req, res) => {
  try {
    const todo = await Todo.findByIdAndDelete(req.params.id);
    if (!todo) {
      return res.status(404).send("Todo not found");
    }
    res.status(200).send("Todo deleted");
  } catch (err) {
    res.status(500).send(err.message);
  }
};

// 清除已完成 todos
// exports.clearCompletedTodos = async (req, res) => {
//   try {
//     await Todo.deleteMany({ completed: true }); // 删除已完成的 todos
//     res.status(200).json({ message: 'Completed todos cleared successfully' });
//   } catch (err) {
//     console.error('Error clearing completed todos:', err);
//     res.status(500).json({ error: 'Failed to clear completed todos' });
//   }
// };
exports.clearCompletedTodos = async (req, res) => {
  try {
    const result = await Todo.deleteMany({ completed: true }); // 删除已完成的 todos
    console.log(`${result.deletedCount} todos deleted`); // 打印成功删除的数量
    res.status(200).json({ message: 'Completed todos cleared successfully' });
  } catch (err) {
    console.error('Error clearing completed todos:', err); // 打印详细错误
    res.status(500).json({ error: 'Failed to clear completed todos' });
  }
};

