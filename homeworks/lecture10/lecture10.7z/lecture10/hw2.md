# Todo List App with Express.js

## Requirements

- [ ] Design and implement a RESTful API for a todo list app using Express.
- [ ] Use template engines to render the views.
- [ ] Use MongoDB to store the data.
- [ ] Design your own models and schemas.