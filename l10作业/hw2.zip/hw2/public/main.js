const todosContainer = document.querySelector(".todos-container"); // 放置 todos 的区域
const inputField = document.getElementById("todo"); // 输入框
const addButton = document.querySelector("button"); // 按钮

//-------------------------------------------
function handleSubmit() {
  const todoInput = document.getElementById('todo');
  const todoText = todoInput.value.trim();

  if (todoText === '') {
      alert('Please enter a todo!');
      return;
  }

  // 创建新 Todo 项目
  const todoList = document.querySelector('.margin-top-20');
  const todoItem = document.createElement('div');
  todoItem.className = 'row margin-top-10';
  todoItem.innerHTML = `
      <div class="col-1">
          <input type="checkbox" class="form-check-input">
      </div>
      <div class="col">${todoText}</div>
  `;

  todoList.appendChild(todoItem);

  // 清空输入框
  todoInput.value = '';
}

function handleCheck(checkbox) {
  console.log(`Checkbox ${checkbox.id} changed to ${checkbox.checked}`);
}

//-----------------------------------------
// 监听按钮点击事件
addButton.addEventListener("click", async () => {
  const todoText = inputField.value.trim();
  if (!todoText) return alert("Please enter a todo");
  console.log('Button clicked, todo input:', todoText);

  try {
    // 发送 POST 请求到后端
    const response = await fetch("/api/todos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ todo: todoText, done: false }),
    });

    if (response.ok) {
      const newTodo = await response.json();

      // 动态更新页面
      const todoElement = document.createElement("div");
      todoElement.className = "row";
      todoElement.innerHTML = `
        <div class="col-1">
          <input
            type="checkbox"
            id="${newTodo._id}"
            class="form-check-input"
            onchange="handleCheck(this)"
          />
        </div>
        <div class="col">
          <label for="${newTodo._id}">${newTodo.todo}</label>
        </div>
      `;
      todosContainer.appendChild(todoElement);

      // 清空输入框
      inputField.value = "";
    } else {
      const error = await response.json();
      alert(`Error: ${error.message}`);
    }
  } catch (err) {
    console.error("Error adding todo:", err);
  }
});

// 页面加载时获取并显示所有 todos
window.onload = async () => {
  try {
    const response = await fetch("/api/todos");
    const todos = await response.json();

    todos.forEach((todo) => {
      const todoElement = document.createElement("div");
      todoElement.className = "row";
      todoElement.innerHTML = `
        <div class="col-1">
          <input
            type="checkbox"
            id="${todo._id}"
            class="form-check-input"
            onchange="handleCheck(this)"
            ${todo.done ? "checked" : ""}
          />
        </div>
        <div class="col">
          <label for="${todo._id}">${todo.todo}</label>
        </div>
      `;
      todosContainer.appendChild(todoElement);
    });
  } catch (err) {
    console.error("Error loading todos:", err);
  }
};

// 勾选事件处理
function handleCheck(checkbox) {
  const todoId = checkbox.id;
  const done = checkbox.checked;

  fetch(`/api/todos/${todoId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ done }),
  }).catch((err) => console.error("Error updating todo:", err));
}
