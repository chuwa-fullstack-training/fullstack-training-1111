// import logo from './logo.svg';
 import './App.css';
// import React from 'react';
// import AppBar from '@mui/material/AppBar';
// import Toolbar from '@mui/material/Toolbar';
// import Typography from '@mui/material/Typography';
// import Box from '@mui/material/Box';
// import TextField from '@mui/material/TextField';
// import InputAdornment from '@mui/material/InputAdornment';
// import SearchIcon from '@mui/icons-material/Search';

// function App() {
//   return (
//     <AppBar position="static" style={{ backgroundColor: '#000' }}>
//     <Toolbar>
//       {/* 左侧文字 */}
//       <Typography variant="h6" component="span" sx={{ flexGrow: 1 }}>
//         我的导航栏
//       </Typography>

//       {/* 中间搜索框 */}
//       <Box>
//         <TextField
//           variant="outlined"
//           placeholder="搜索..."
          
//           sx={{ width: '300px' }}
//         />
//       </Box>
//     </Toolbar>
//   </AppBar>
//   );
// }

// export default App;


// import React, { useState } from "react";
// import { useSelector, useDispatch } from "react-redux";
// import { addTodo, deleteTodo, toggleStatus } from "./store/toolkitIndex.js";

// function App() {
//   const todos = useSelector((state) => state.todoReducer.todos);
//   const dispatch = useDispatch();

//   const [newTodo, setNewTodo] = useState("");

//   const handleAddTodo = () => {
//     if (newTodo.trim()) {
//       dispatch(addTodo(newTodo));
//       setNewTodo("");
//     }
//   };

//   const handleDeleteTodo = (index) => {
//     dispatch(deleteTodo(index));
//   };

//   return (
//     <div>
//       <h1>Redux Todo List</h1>
//       <div>
//         <input
//           type="text"
//           value={newTodo}
//           onChange={(e) => setNewTodo(e.target.value)}
//           placeholder="添加一个新的待办事项"
//         />
//         <button onClick={handleAddTodo}>添加</button>
//       </div>
//       <ul>
//         {todos.map((todo, index) => (
//           <li key={index}>
//             {todo}
//             <button onClick={() => handleDeleteTodo(index)}>删除</button>
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// }

// export default App;

//-----------------------------------------------
// import React, { useState ,useEffect} from "react";
// import { useSelector, useDispatch } from "react-redux";
// import {
//   addTodo,
//   toggleTodo,
//   clearFinishedTodos,
// } from "./store/toolkitIndex.js";


// export default function App() {

//   useEffect(()=>{
//     fetch('http://localhost:3001/').then(res=>res.json()).then(data=>console.log(data));
//   })

//   const [inputValue, setInputValue] = useState("");
//   const todos = useSelector((state) => state.todoSlice.todos); // 从 Redux 中获取 todos
//   const dispatch = useDispatch();

//   const handleInputChange = (e) => {
//     setInputValue(e.target.value);
//   };

//   const handleKeyPress = (e) => {
//     if (e.key === "Enter" && inputValue.trim() !== "") {
//       dispatch(addTodo(inputValue)); // Dispatch 添加 todo 的动作
//       setInputValue("");
//     }
//     console.log("Todos in Redux state:", todos);

//   };

//   const handleToggleTodo = (index) => {
//     dispatch(toggleTodo(index)); // Dispatch 切换完成状态的动作
//   };

//   const handleClearFinishedTodos = () => {
//     dispatch(clearFinishedTodos()); // Dispatch 清除已完成任务的动作
//   };

//   const remainingCount = todos.filter((todo) => !todo.completed).length;

//   return (
//     <div className="App">
//       <input
//         type="text"
//         placeholder="Enter a todo"
//         value={inputValue}
//         onChange={handleInputChange}
//         onKeyPress={handleKeyPress}
//       />
//       <div
//         style={{
//           display: "flex",
//           justifyContent: "space-between",
//           margin: "10px 0",
//         }}
//       >
//         <span>{remainingCount} remaining</span>
//         <button onClick={handleClearFinishedTodos}>
//           Clear All Finished Todos
//         </button>
//       </div>
//       <ul>
//         {todos.map((todo, index) => (
//           <li
//             key={index}
//             style={{ display: "flex", alignItems: "center", margin: "5px 0" }}
//           >
//             <input
//               type="checkbox"
//               checked={todo.completed}
//               onChange={() => handleToggleTodo(index)}
//             />
//             <span
//               style={{
//                 textDecoration: todo.completed ? "line-through" : "none",
//                 marginLeft: "10px",
//               }}
//             >
//               {todo.text}
//             </span>
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// }


// import React, { useState, useEffect } from "react";
// import axios from "axios";

// export default function App() {
//   const [todos, setTodos] = useState([]);
//   const [inputValue, setInputValue] = useState("");

//   // 后端 API 基础 URL
//   const API_URL = "http://localhost:3001/api/todos";

//   // 获取 Todos 数据
//   useEffect(() => {
//     const fetchTodos = async () => {
//       try {
//         const response = await axios.get(API_URL);
//         setTodos(response.data); // 更新状态
//       } catch (error) {
//         console.error("Error fetching todos:", error);
//       }
//     };
//     fetchTodos();
//   }, []);

//   // 添加新 Todo
//   const handleKeyPress = async (e) => {
//     if (e.key === "Enter" && inputValue.trim() !== "") {
//       try {
//         const response = await axios.post(API_URL, { text: inputValue });
//         setTodos([...todos, response.data]); // 添加新 todo
//         setInputValue("");
//       } catch (error) {
//         console.error("Error adding todo:", error);
//       }
//     }
//   };

//   // 切换 Todo 状态
//   const toggleTodo = async (id) => {
//     try {
//       const updatedTodo = todos.find((todo) => todo._id === id);
//       const response = await axios.patch(`${API_URL}/${id}`, {
//         completed: !updatedTodo.completed,
//       });
//       setTodos(
//         todos.map((todo) =>
//           todo._id === id ? { ...todo, completed: response.data.completed } : todo
//         )
//       );
//     } catch (error) {
//       console.error("Error toggling todo:", error);
//     }
//   };

//   // 清除已完成 Todos
//   // const clearFinishedTodos = async () => {
//   //   try {
//   //     await axios.delete(`${API_URL}/completed`);
//   //     setTodos(todos.filter((todo) => !todo.completed));
//   //   } catch (error) {
//   //     console.error("Error clearing completed todos:", error);
//   //   }
//   // };
//   const clearFinishedTodos = async () => {
//     try {
//       await axios.delete(`${API_URL}/completed`); // 调用后端删除已完成 todos
//       // const response = await axios.get(API_URL); // 重新获取最新 todos 数据
//       // setTodos(response.data); // 更新 todos 状态
//       setTodos(todos.filter((todo) => !todo.completed));
//     } catch (error) {
//       console.error("Error clearing completed todos:", error);
//     }
//   };

//   // 未完成 Todo 数量
//   const remainingCount = todos.filter((todo) => !todo.completed).length;

//   return (
//     <div className="App">
//       <input
//         type="text"
//         placeholder="Enter a todo"
//         value={inputValue}
//         onChange={(e) => setInputValue(e.target.value)}
//         onKeyPress={handleKeyPress}
//       />
//       <div
//         style={{
//           display: "flex",
//           justifyContent: "space-between",
//           margin: "10px 0",
//         }}
//       >
//         <span>{remainingCount} remaining</span>
//         <button onClick={clearFinishedTodos}>Clear All Finished Todos</button>
//       </div>
//       <ul>
//         {todos.map((todo) => (
//           <li
//             key={todo._id}
//             style={{ display: "flex", alignItems: "center", margin: "5px 0" }}
//           >
//             <input
//               type="checkbox"
//               checked={todo.completed}
//               onChange={() => toggleTodo(todo._id)}
//             />
//             <span
//               style={{
//                 textDecoration: todo.completed ? "line-through" : "none",
//                 marginLeft: "10px",
//               }}
//             >
//               {todo.text}
//             </span>
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// }


import React, { useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  useNavigate,
  useParams,
} from "react-router-dom";

const ComponentBox = ({ id, name, color, onNameChange, navigateTo }) => {
  return (
    <div
      style={{
        width: "200px",
        height: "120px",
        border: "1px solid #ccc",
        borderRadius: "5px",
        margin: "10px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "space-between",
        backgroundColor: color || "#fff",
        padding: "10px",
      }}
    >
      <input
        type="text"
        value={name}
        onChange={(e) => onNameChange(id, e.target.value)}
        style={{ marginBottom: "10px", textAlign: "center" }}
      />
      <button onClick={() => navigateTo(id)} style={{ padding: "5px 10px" }}>
        View Details
      </button>
    </div>
  );
};

const ComponentPage = ({ components, onNameChange, onColorChange }) => {
  const navigate = useNavigate();
  const { id } = useParams();
  const component = components.find((comp) => comp.id === Number(id));

  return (
    <div style={{ textAlign: "center", marginTop: "20px" }}>
      <h2>Component Selector</h2>
      {component ? (
        <>
          <h3>{component.name} Component</h3>
          <div
            style={{
              width: "200px",
              height: "100px",
              margin: "20px auto",
              border: "1px solid #ccc",
              backgroundColor: component.color || "#fff",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <p>{component.name}</p>
          </div>
          <div style={{ marginTop: "20px" }}>
            <label>
              Change color:
              <select
                value={component.color || ""}
                onChange={(e) =>
                  onColorChange(component.id, e.target.value)
                }
                style={{ marginLeft: "10px" }}
              >
                <option value="">Choose color</option>
                <option value="lightblue">Light Blue</option>
                <option value="lightgreen">Light Green</option>
                <option value="lightcoral">Light Coral</option>
                <option value="lightgoldenrodyellow">Light Yellow</option>
              </select>
            </label>
          </div>
        </>
      ) : (
        <h3>Component not found</h3>
      )}
      <br />
      <button onClick={() => navigate("/")} style={{ marginTop: "20px" }}>
        Back to Home
      </button>
    </div>
  );
};

const App = () => {
  const [components, setComponents] = useState([
    { id: 1, name: "first", color: "" },
    { id: 2, name: "second", color: "" },
    { id: 3, name: "third", color: "" },
    { id: 4, name: "fourth", color: "" },
    { id: 5, name: "fifth", color: "" },
    { id: 6, name: "sixth", color: "" },
  ]);

  const navigate = useNavigate();

  const handleNameChange = (id, newName) => {
    setComponents((prev) =>
      prev.map((comp) =>
        comp.id === id ? { ...comp, name: newName } : comp
      )
    );
  };

  const handleColorChange = (id, color) => {
    setComponents((prev) =>
      prev.map((comp) => (comp.id === id ? { ...comp, color } : comp))
    );
  };

  const handleNavigate = (id) => {
    navigate(`/component/${id}`);
  };

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h1>Component Selector</h1>
      <Routes>
        <Route
          path="/"
          element={
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(3, 1fr)",
                gap: "10px",
                marginTop: "20px",
              }}
            >
              {components.map((comp) => (
                <ComponentBox
                  key={comp.id}
                  id={comp.id}
                  name={comp.name}
                  color={comp.color}
                  onNameChange={handleNameChange}
                  navigateTo={handleNavigate}
                />
              ))}
            </div>
          }
        />
        <Route
          path="/component/:id"
          element={
            <ComponentPage
              components={components}
              onNameChange={handleNameChange}
              onColorChange={handleColorChange}
            />
          }
        />
      </Routes>
    </div>
  );
};

export default App;
