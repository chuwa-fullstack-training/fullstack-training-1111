// const express = require('express');
// const cors = require('cors');

// const app = express()
// const port = 3001;

// app.use(cors());
// app.get('/', (req, res) => {
//   res.json('Hello World!')
// })

// app.listen(port, () => {
//   console.log(`Example app listening on port ${port}`)
// })

const express = require('express');
const cors = require('cors');
const connectDB = require('./db'); // 引入你的数据库连接模块
const todoRoutes = require('./router/todoRouter'); // 引入路由模块

require('dotenv').config(); // 加载 .env 文件中的环境变量

const app = express();
const port = process.env.PORT || 3001;

// 中间件
app.use(cors());
app.use(express.json()); // 解析 JSON 请求体

// 数据库连接
connectDB();

// 路由
app.use('/api/todos', todoRoutes); // 使用 todos 路由

// 测试路由
app.get('/', (req, res) => {
  res.json('Hello World!');
});

// 启动服务器
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
