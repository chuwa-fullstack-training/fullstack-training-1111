const express = require('express');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
app.use(express.json());

// 路由模块
const companyRoutes = require('./routes/companies');
const employeeRoutes = require('./routes/employees');
const authRoutes = require('./routes/auth');

// 路由中间件
app.use('/api/companies', companyRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api', authRoutes);

module.exports = app;
