const express = require('express');
const router = express.Router();
const {
  getTodos,
  addTodo,
  toggleTodo,
  deleteTodo,
  clearCompletedTodos
} = require('../controller/todoController');

// 获取所有 todos
router.get('/', getTodos);

// 添加新的 todo
router.post('/', addTodo);

// 切换完成状态
router.patch('/:id', toggleTodo);

// 删除所有已完成的 todos
router.delete('/completed', clearCompletedTodos); // 新增路由

// 删除一个 todo
router.delete('/:id', deleteTodo);//要放在/completed下面



module.exports = router;
